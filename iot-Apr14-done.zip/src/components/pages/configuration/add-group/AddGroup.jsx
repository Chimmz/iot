import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';

import * as userSelectors from '../../../../redux/user/user-selectors';
import * as portfolioSelectors from '../../../../redux/portfolio/portfolio-selectors';

import useInput from '../../../../hooks/useInput';
import API from '../../../../utils/apiUtils';

import Backdrop from '../../../UI/backdrop/Backdrop';
import InputField from '../../../UI/InputField';

import useList from '../../../../hooks/useList';
import useMultiSelect from '../../../../hooks/useMultiSelect';
import useFetch from '../../../../hooks/useFetch';

import { configurationContext } from '../../../../contexts/configurationContext';

import {
   getIncidentTypeOptions,
   getNotificationOptions,
   getAvailabilityOptions,
   getSelectionValues
} from './utils';

import InputGroup from 'react-bootstrap/InputGroup';
import MultipleSelect from '../../../UI/multi-select/MultipleSelect';
import Spinner from '../../../UI/spinner/Spinner';
import './AddGroup.scss';

function AddGroup(props) {
   const { currentUser, currentPortfolio, userToken, show } = props;

   const navigate = useNavigate();

   const close = callback => {
      navigate(-1);
      callback?.();
   };

   const { setGroupsUpdated } = useContext(configurationContext);

   const [searchResults, setSearchResults] = useState([]);

   const [incidentTypes, setIncidentTypes] = useState([]);
   const [notifTypes, setNotifTypes] = useState([]);
   const [searchResultsFilter, setSearchResultsFilter] = useState([]);
   const [availabilities, setAvailabilities] = useState([]);

   const {
      items: addedUsers,
      addItem: includeUser,
      removeItem: excludeUser
   } = useList();

   const {
      inputValue: groupName,
      handleChange: handleChangeGroupName,
      runValidators: runGroupNameValidators,
      validationErrors: groupNameValidationErrors,
      setValidationErrors: setGroupNameValidationErrors
   } = useInput({ init: '', validators: [{ isRequired: [] }] });

   // prettier-ignore
   const {
      selections: selectedIncidentTypes,
      setSelections: setSelectedIncidentTypes,
      runValidators: runIncidentTypeValidators,
      validationErrors: incidentTypeValidationErrors,
      setValidationErrors: setIncidentTypeValidationErrors
   } = useMultiSelect({
      init: [],
      validators: [{
         minLength: [1, 'No incident type selected']
      }]
   });

   // prettier-ignore
   const {
      selections: selectedNotifs,
      setSelections: setSelectedNotifs,
      runValidators: runNotifsValidators,
      validationErrors: notifValidationErrors,
      setValidationErrors: setNotifsValidationErrors
   } = useMultiSelect({
      init: [],
      validators: [{
         minLength: [1, 'No notification type selected']
      }]
   });

   const { inputValue: searchUser, handleChange: handleChangeSearchUserInput } =
      useInput({ init: '', validators: [{ isRequired: [] }] });

   // prettier-ignore
   const {
      selections: selectedAvailabs,
      setSelections: setSelectedAvailabs,
      runValidators: runAvailabilityValidators,
      validationErrors: availabilityValidationErrors,
      setValidationErrors: setAvailabilityValidationErrors
   } = useMultiSelect({
      init: [],
      validators: [{
         minLength: [1, 'No availability type selected']
      }]
   });

   const { sendRequest: sendManyRequests, loading: getAllTypesLoading } =
      useFetch();

   const handleSave = async function (ev) {
      ev.preventDefault();
      const groupErrs = runGroupNameValidators();
      const incidErrs = runIncidentTypeValidators();
      const notifsErrs = runNotifsValidators();
      const availabErrs = runAvailabilityValidators();
      // prettier-ignore
      if (groupErrs.length || incidErrs.length || notifsErrs.length || availabErrs.length) {
         setGroupNameValidationErrors(groupErrs);
         setIncidentTypeValidationErrors(incidErrs);
         setNotifsValidationErrors(notifsErrs)
         return setAvailabilityValidationErrors(availabErrs)
      }

      const body = {
         groupId: 0,
         groupName,
         userId: currentUser.userId,
         userIds: [...addedUsers],
         incidentTypeIdList: [...getSelectionValues(selectedIncidentTypes)],
         availabilityIdList: [...getSelectionValues(selectedAvailabs)],
         notificationTypeIdList: [...getSelectionValues(selectedNotifs)]
      };
      console.log(body);

      try {
         const res = await API.createGroup(body, userToken);
         console.log(res);

         const doAfterClose = () => setGroupsUpdated(true);
         close(doAfterClose);
      } catch (err) {
         console.log(err);
      }
   };

   const addOrRemoveUser = (user, ev) => {
      (ev.target.checked ? includeUser : excludeUser)(user.userId);
   };

   useEffect(() => {
      if (!searchUser) return setSearchResultsFilter(searchResults);

      const matches = searchResults.filter(({ firstName, lastName }) =>
         (firstName + lastName).toLowerCase().includes(searchUser.toLowerCase())
      );
      setSearchResultsFilter(matches);
   }, [searchUser]);

   useEffect(async () => {
      const makeManyRequests = () =>
         sendManyRequests(
            // Promise.all() returns resultant unawaited promise
            Promise.all([
               API.getIncidentTypes(userToken),
               API.getNotificationTypes(userToken),
               API.getAvailabilities(userToken),
               API.getUsersInPortfolio(
                  currentPortfolio?.portfolioHeaderId,
                  userToken
               )
            ])
         );

      // prettier-ignore
      const setters = [setIncidentTypes, setNotifTypes, setAvailabilities, setSearchResults]
      const responses = await makeManyRequests();

      for (const [i, set] of Object.entries(setters)) set(responses[i]);
   }, []);

   const containerClassName = `add-group thin-scrollbar ${
      props.show ? 'show' : 'fade'
   }`;

   return (
      <>
         <Backdrop show={props.show} />
         <div className={containerClassName}>
            <h2 className="page-heading fw-600 mb-lg my-sm-5">
               Add New User Group
            </h2>
            <form onSubmit={handleSave} className="w-md-75">
               <InputGroup className="mb-4 row">
                  <label
                     htmlFor="groupName"
                     className="col-sm-4 col-form-label"
                  >
                     Group Name
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <InputField
                        type="text"
                        id="groupName"
                        className=""
                        value={groupName}
                        onChange={handleChangeGroupName}
                        validationErrors={groupNameValidationErrors}
                     />
                  </div>
               </InputGroup>
               <hr className="my-3"></hr>

               <InputGroup className="row">
                  <label
                     htmlFor="incidentType"
                     className="col-sm-4 col-form-label"
                  >
                     Incident Type
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <MultipleSelect
                        options={getIncidentTypeOptions(incidentTypes)}
                        value={selectedIncidentTypes}
                        onChange={setSelectedIncidentTypes}
                        validationErrors={incidentTypeValidationErrors}
                     />
                  </div>
               </InputGroup>

               <InputGroup className="row">
                  <label
                     htmlFor="incidentType"
                     className="col-sm-4 col-form-label"
                  >
                     Communication Type
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <MultipleSelect
                        options={getNotificationOptions(notifTypes)}
                        value={selectedNotifs}
                        onChange={setSelectedNotifs}
                        validationErrors={notifValidationErrors}
                     />
                  </div>
               </InputGroup>

               <InputGroup className="row mb-4">
                  <label
                     htmlFor="searchUser"
                     className="col-sm-4 col-form-label"
                  >
                     Search User
                     <br />
                     (Optional)
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <InputField
                        type="text"
                        id="searchUser"
                        className=""
                        value={searchUser}
                        onChange={handleChangeSearchUserInput}
                        validationErrors={[]}
                     />
                  </div>
                  <div className="col-sm-4 col-form-label"></div>
                  <div
                     className="col-sm-8 search thin-scrollbar"
                     style={{ position: 'relative' }}
                  >
                     {(searchResultsFilter.length
                        ? searchResultsFilter
                        : searchResults
                     )?.map(user => (
                        <div
                           className="search-result d-flex"
                           key={user.emailId}
                        >
                           <input
                              type="checkbox"
                              id={user.emailId}
                              onChange={ev => addOrRemoveUser(user, ev)}
                           />
                           <label
                              htmlFor={user.emailId}
                              className="result-name"
                           >
                              {user.firstName + ' ' + user.lastName}
                           </label>
                        </div>
                     ))}
                  </div>
               </InputGroup>

               <InputGroup className="row">
                  <label
                     htmlFor="incidentType"
                     className="col-sm-4 col-form-label"
                  >
                     Availability
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <MultipleSelect
                        options={getAvailabilityOptions(availabilities)}
                        value={selectedAvailabs}
                        onChange={setSelectedAvailabs}
                        validationErrors={availabilityValidationErrors}
                     />
                  </div>
               </InputGroup>

               <div className="actions">
                  <button
                     type="submit"
                     className="rounded btn btn-primary"
                     data-dismiss="modal"
                     aria-label="Close"
                  >
                     Save
                  </button>
                  <button
                     type="button"
                     className="rounded btn btn-outline-dark"
                     data-dismiss="modal"
                     aria-label="Close"
                     onClick={close}
                  >
                     Cancel
                  </button>
               </div>
            </form>
         </div>
         <Spinner show={getAllTypesLoading} />
      </>
   );
}

const mapStateToProps = createStructuredSelector({
   currentUser: userSelectors.selectCurrentUser,
   currentPortfolio: portfolioSelectors.selectCurrentPortfolio,
   userToken: userSelectors.selectUserToken
});

export default connect(mapStateToProps)(AddGroup);
