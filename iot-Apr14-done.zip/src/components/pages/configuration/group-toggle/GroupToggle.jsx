import React, { useEffect, useContext } from 'react';

import useToggle from '../../../../hooks/useToggle';
import API from '../../../../utils/apiUtils';

import { configurationContext } from '../../../../contexts/configurationContext';
import Toggler from '../../../UI/toggler/Toggler';

import Spinner from 'react-bootstrap/Spinner';
import useFetch from '../../../../hooks/useFetch';

function GroupToggle({ groupId, userToken }) {
   const { allGroupDetails, setAllGroupDetails, fetchGroupDetails } =
      useContext(configurationContext);

   const [turnedOn, toggle, _, __, setToggleState] = useToggle(false);

   const {
      sendRequest: sendGetGroupDetailsRequest,
      loading: requestGroupDetailsLoading
   } = useFetch();

   const { sendRequest: requestToggle, loading: requestToggleLoading } =
      useFetch();

   const getCurrentToggleStatus = async () => {
      const groupDetails =
         allGroupDetails[groupId] ||
         (await sendGetGroupDetailsRequest(
            API.getGroupDetails(groupId, userToken)
         ));

      const toggleStatus = { 1: true, 2: false };
      return toggleStatus[groupDetails?.group?.groupStatusId] || false;
   };

   const handleSwitch = async () => {
      requestToggle(API.toggleGroupStatus(groupId, userToken))
         .then(toggle)
         .catch(err => {
            console.log(err);
         });
   };

   useEffect(async () => {
      const initialToggleState = await getCurrentToggleStatus();
      setToggleState(initialToggleState);
   }, []);

   return (
      <div className="d-flex align-items-center" style={{ gap: '5px' }}>
         <Toggler isOn={turnedOn} onSwitch={handleSwitch} id={groupId} />
         {requestToggleLoading && <Spinner animation="border" size="sm" />}
      </div>
   );
}

export default GroupToggle;
