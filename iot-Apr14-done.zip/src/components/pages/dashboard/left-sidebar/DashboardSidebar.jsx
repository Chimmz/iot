import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';

import { dashboardContext } from '../../../../contexts/dashboardContext';
import { v4 as uuidv4 } from 'uuid';

import Dropdown from 'react-bootstrap/Dropdown';
import { sidebarLinks } from './config';
import './DashboardSidebar.scss';

// TO ADD A NEW LINK TO THE SIDEBAR, ADD IT IN ./sidebarLinks.js

function DashboardSidebar() {
   const { toggleSidebarCollapsed } = useContext(dashboardContext);
   const getLinkActiveClassName = navData => navData.isActive && 'active';

   const getDropdownLinkJSX = function (link) {
      const getDropdownItem = item => (
         <Dropdown.Item key={item.linkTo}>
            <NavLink to={item.linkTo}>{item.label}</NavLink>
         </Dropdown.Item>
      );
      return (
         <Dropdown key={uuidv4()}>
            <Dropdown.Toggle
               key={link.linkTo}
               className="drop__btn after pad-0 after d-flex align-items-center"
               id="courseDrop"
               activeClassName={getLinkActiveClassName}
               role="button"
               data-bs-toggle="dropdown"
               aria-haspopup="true"
               aria-expanded="true"
            >
               <NavLink
                  to={link.linkTo}
                  className="drop__btn after"
                  activeClassName={getLinkActiveClassName}
               >
                  <img src={process.env.PUBLIC_URL + link.imgSrc} />
                  <span>{link.label}</span>
               </NavLink>
            </Dropdown.Toggle>

            <Dropdown.Menu>{link.sublinks.map(getDropdownItem)}</Dropdown.Menu>
         </Dropdown>
      );
   };

   const getSingleLinkJSX = link => (
      <li key={uuidv4()}>
         <NavLink
            key={link.linkTo}
            to={link.linkTo}
            className="drop__btn"
            activeClassName={getLinkActiveClassName}
         >
            <img src={process.env.PUBLIC_URL + link.imgSrc} />
            <span>{link.label}</span>
         </NavLink>
      </li>
   );

   return (
      <aside className="mainSideBar col">
         <p className="title fs14">main</p>
         <button
            className="btn btn-close d-md-none"
            onClick={toggleSidebarCollapsed}
         ></button>

         <ul className="link__box">
            {sidebarLinks.map(link =>
               link.hasSublinks
                  ? getDropdownLinkJSX(link)
                  : getSingleLinkJSX(link)
            )}
         </ul>
      </aside>
   );
}

export default DashboardSidebar;
