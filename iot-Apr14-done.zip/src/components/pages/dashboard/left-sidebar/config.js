export const sidebarLinks = [
   {
      linkTo: 'dashboard',
      hasSublinks: true,
      imgSrc: '/images/icons/home.svg',
      label: 'Dashboard',
      sublinks: [
         { linkTo: 'overview', label: 'Overview' },
         { linkTo: 'highlights', label: 'Highlights' }
      ]
   },
   {
      linkTo: 'devices',
      imgSrc: '/images/icons/iot.svg',
      label: 'IoT Devices'
   },
   {
      linkTo: 'telemetry',
      imgSrc: '/images/icons/telemetry.svg',
      label: 'Telemetry'
   },
   {
      linkTo: 'notifications',
      imgSrc: '/images/icons/notification.svg',
      label: 'Notification Center'
   },
   {
      linkTo: 'admin-panel',
      label: 'Admin Panel',
      hasSublinks: true,
      imgSrc: '/images/icons/admin.svg',
      sublinks: [
         { linkTo: 'admin-panel/configuration', label: 'Configuration' }
      ]
   }
];
