import React from 'react';
import { useLocation } from 'react-router-dom';
import withPageHeader from '../../HOC/withPageHeader';
import PageHeader from '../../page-header/PageHeader';

function IotDevices() {
   return (
      <div>
         <PageHeader location={useLocation()} />
         <h1>Devices</h1>
      </div>
   );
}

export default IotDevices;
