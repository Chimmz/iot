import React, { useState, useEffect, useContext, useRef } from 'react';
import { useLocation } from 'react-router-dom';

// Redux
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import * as portfolioSelectors from '../../../redux/portfolio/portfolio-selectors';
import * as userSelectors from '../../../redux/user/user-selectors';
import * as incidentSelectors from '../../../redux/incident/incident-selectors';

import * as incidentUtils from '../../../redux/incident/incident-utils';

import Spinner from '../../UI/spinner/Spinner';
import IotTable from '../../iot-table/IotTable';

import {
   tableColumns,
   getTableData,
   dateFilterPeriods,
   sortByStartTime
} from './table-config.js';

import PageHeader from '../../page-header/PageHeader';
import './Telemetry.scss';

function Telemetry(props) {
   const { currentPortfolio, userToken } = props;
   const [incidents, setIncidents] = useState(props.incidents);

   const [currentTimePeriod, setCurrentTimePeriod] = useState('1-week');
   const [filteredDataLoading, setIsFilteredDataLoading] = useState(false);

   const loadIncidents = async () => {
      const makeRequest = () => {
         return incidentUtils.fetchIncidents(
            currentPortfolio,
            currentTimePeriod,
            userToken
         );
      };
      const res = incidentUtils.handleFilterLoadingAsync(
         makeRequest,
         setIsFilteredDataLoading
      );
      const incids = await res;
      console.log('INCIDS: ', incids);
      setIncidents(incids);
   };

   useEffect(() => {
      if (currentPortfolio) loadIncidents();

      return () => {};
   }, [currentTimePeriod, currentPortfolio?.portfolioHeaderId]);

   const handleDateFilter = function (evKey) {
      const periodSelected = evKey;
      if (periodSelected === currentTimePeriod) return; // If active date filter was selected again
      setCurrentTimePeriod(evKey);
   };

   return (
      <>
         <Spinner show={filteredDataLoading} message="Getting records..." />
         <PageHeader location={useLocation()} />
         <div className="card px-3 py-5 flex-grow data-card telemetry">
            <h2 className="page-heading fw-600 mb-lg">Telemetry </h2>

            <IotTable
               columns={tableColumns}
               data={getTableData(sortByStartTime(incidents, 'descend'))}
               currentTimePeriod={currentTimePeriod}
               dateFilterPeriods={dateFilterPeriods}
               onDateFilter={handleDateFilter}
            />

            {/* <div className="date-filter" ref={dateFilterRef}>
               <span>Filter by date range: </span>
               <DropdownButton
                  variant="outline-secondary"
                  id="segmented-button-dropdown-1"
                  size="sm"
                  title={getTimePeriodTitle()}
                  onSelect={handleDateFilter}
               >
                  {dateFilterPeriods.map(period => (
                     <Dropdown.Item key={period} eventKey={period}>
                        {getTimePeriodTitle(period)}
                     </Dropdown.Item>
                  ))}
               </DropdownButton>
            </div>
            
            <EukaDataTable
               columns={tableColumns}
               data={tableData}
               options={tableOptions}
               
            /> */}
            {/* <div className="iot-table">
               <div className="iot-table__controls ">
                  <div className="iot-table__entries-count d-flex align-items-center mr-auto">
                     <span>Show</span>
                     <input
                        type="number"
                        className="form-control w-max-content"
                        min="5"
                        step="5"
                     />
                     <span>entries</span>
                  </div>
                  <div className="iot-table__sort">
                     <DropdownButton title="All floors" variant="none">
                        <Dropdown.Item eventKey="2">Ascending</Dropdown.Item>
                        <Dropdown.Item eventKey="3" active>
                           Descending
                        </Dropdown.Item>
                     </DropdownButton>
                  </div>
                  <div className="iot-table__search d-flex align-items-center">
                     <span>Search:</span>
                     <input type="text" className="form-control" />
                  </div>
               </div>
               <div className="iot-table__datatable"></div>

               

               <div className="iot-table__pagination d-flex justify-content-between">
                  <span>Showing 1 to 10 of 246 entries</span>
                  <div className="iot-table__pagination__control d-flex align-items-center">
                     <label>&lt;</label>
                     <span>1</span>
                     <span className="active">2</span>
                     <span>3</span>
                     <span>4</span>
                     <label>&gt;</label>
                  </div>
               </div>
            </div> */}
         </div>
      </>
   );
}

const mapStateToProps = createStructuredSelector({
   currentPortfolio: portfolioSelectors.selectCurrentPortfolio,
   incidentsLoading: incidentSelectors.selectIncidentLoading,
   userToken: userSelectors.selectUserToken
});

export default connect(mapStateToProps)(Telemetry);
