import * as dateUtils from '../../../utils/dateUtils';
import * as strUtils from '../../../utils/stringUtils';

export const tableFields = [
   'alert type',
   'location',
   'floor',
   'start time',
   'end time',
   'status',
   'incident record'
];

export const tableColumns = tableFields.map(field => {
   const column = {
      name: strUtils.toCamelCase(field),
      label: strUtils.toTitleCase(field)
   };
   return column;
});

export const getTableData = incidents => {
   if (!incidents?.length) return [];

   return incidents.map(incid => ({
      alertType: incid.displayName,
      location: incid.roomName + ' - ' + incid.zoneName,
      floor: incid.floorName.split(' ')[1],
      startTime: dateUtils.getDateAndTime(incid.startTime),
      endTime: !incid.endTime ? '-' : dateUtils.getDateAndTime(incid.endTime),
      status: incid.incidentStatus,
      incidentRecord: incid.incidentRecordHeaderName || '-'
   }));
};

// prettier-ignore
export const dateFilterPeriods = ['1-week', '1-month', '3-month', '6-month', '9-month', '1-year'];

export const sortByStartTime = (incidents, sortOrder = 'ascend') => {
   if (!incidents?.length) return [];
   if (!sortOrder) return incidents;

   const sortedData = incidents?.sort((currRow, nextRow) => {
      const currStartTime = +new Date(currRow.startTime);
      const nextStartTime = +new Date(nextRow.startTime);

      if (sortOrder === 'ascend') {
         if (currStartTime < nextStartTime) return -1;
         return 1;
      }
      if (currStartTime < nextStartTime) return 1;
      return -1;
   });
   return sortedData;
};
