import React from 'react';
import { useLocation } from 'react-router-dom';
import PageHeader from '../../page-header/PageHeader';

function Notifs() {
   return (
      <>
         <PageHeader location={useLocation()} />
         <h1>Notifications</h1>
      </>
   );
}

export default Notifs;
