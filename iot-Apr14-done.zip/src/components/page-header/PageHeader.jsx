import React from 'react';
import { Link } from 'react-router-dom';
import * as strUtils from '../../utils/stringUtils';

import './PageHeader.scss';

export default function PageHeader(props) {
   let pageUrl = props.location.pathname
      .replaceAll('/', ' / ')
      .trim()
      .split(' ');

   // console.log(pageUrl);

   const pageNavigation = pageUrl.map((text, _i) => {
      if (text === '/') return <span key={_i}>/</span>;

      const subdirName = strUtils.toTitleCase(text.split('-').join(' '));
      const subdirLink = pageUrl.slice(0, _i + 1).join('');

      if (_i !== pageUrl.length - 1)
         return (
            <Link to={subdirLink} key={_i}>
               {subdirName}
            </Link>
         );
      return <span key={_i}>{subdirName}</span>;
   });

   return (
      <div className="page__header d-flex align-items-center">
         <Link to="/dashboard">
            <img src={process.env.PUBLIC_URL + '/images/icons/home.svg'} />
         </Link>

         {pageNavigation}
      </div>
   );
}
