import React, { useState } from 'react';
import Dialog from '../dialog/Dialog';
import Button from 'react-bootstrap/Button';

function DeleteConfirmation(props) {
   const { show, bodyText, onDelete, close } = props;

   const handleDelete = () => {
      onDelete();
      close();
   };

   if (!show) return <></>;

   return (
      <Dialog show={show}>
         <Dialog.Header>
            <h2>Delete Confirmation</h2>
         </Dialog.Header>
         <Dialog.Body>
            {bodyText || 'Are you sure you want to delete?'}
         </Dialog.Body>
         <Dialog.Footer>
            <Button variant="danger" onClick={handleDelete}>
               Yes, delete
            </Button>
            <Button variant="outline-dark " onClick={close}>
               Cancel
            </Button>
         </Dialog.Footer>
      </Dialog>
   );
}

export default DeleteConfirmation;
