import { useState } from 'react';

const useToggle = function (initState = false) {
   const [state, setState] = useState(initState);

   const toggle = () => setState(!state);
   const reset = () => setState(initState);
   const setOn = () => setState(true);
   const setOff = () => setState(false);

   return [state, toggle, setOn, setOff, setState, reset];
};

export default useToggle;
