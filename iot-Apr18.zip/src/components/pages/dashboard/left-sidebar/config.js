export const sidebarLinks = [
   {
      linkTo: 'dashboard',
      hasSublinks: true,
      imgSrc: '/images/icons/home-solid.png',
      label: 'Dashboard',
      sublinks: [
         { linkTo: 'overview', label: 'Overview' },
         { linkTo: 'highlights', label: 'Highlights' }
      ]
   },
   {
      linkTo: 'devices',
      imgSrc: '/images/icons/iot-solid.png',
      label: 'IoT Devices'
   },
   {
      linkTo: 'telemetry',
      imgSrc: '/images/icons/telemetry-solid.png',
      label: 'Telemetry'
   },
   {
      linkTo: 'notifications',
      imgSrc: '/images/icons/notification-solid.png',
      label: 'Notification Center'
   },
   {
      label: 'Admin Panel',
      hasSublinks: true,
      imgSrc: '/images/icons/admin-solid.png',
      sublinks: [
         { linkTo: 'admin-panel/configuration', label: 'Configuration' },
         { linkTo: 'admin-panel/users-list', label: 'Users List' }
      ]
   }
];
