import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import * as userSelectors from '../../../redux/user/user-selectors';

import useFetch from '../../../hooks/useFetch';

import API from '../../../utils/apiUtils';
import { tableColumns } from './table-config';

import IotTable from '../../iot-table/IotTable';
import UserActions from './actions-on-user/UserActions';
import PageHeader from '../../page-header/PageHeader';
import Spinner from '../../UI/spinner/Spinner';
import Toggler from '../../UI/toggler/Toggler';
import ToggleUser from './toggle-user/ToggleUser';

function UsersList({ userToken }) {
   const [users, setUsers] = useState([]);
   const { sendRequest: sendUserListRequest, loading: userListRequestLoading } =
      useFetch();

   // Must use the 'function' keyword because of the use of the 'this' keyword
   const toggleUserStatus = function () {
      console.log(this);
   };

   const getTableData = function () {
      if (!users.length) return [];

      return users.map(u => ({
         userName: u.firstName + ' ' + u.lastName,
         propertyName: u.propertyName,
         phone: u.contactNumber,
         group: u.roleName,
         primaryEmail: (
            <div
               className="overflow-x-scroll thin-scrollbar"
               style={{ maxWidth: '15ch' }}
            >
               {u.emailID}
            </div>
         ),
         action: <UserActions user={u} userToken={userToken} />,
         active: <ToggleUser user={u} userToken={userToken} />
      }));
   };

   useEffect(async () => {
      const req = sendUserListRequest(API.getUsersList(userToken));
      req.then(setUsers).catch(console.log);
   }, []);

   return (
      <>
         <PageHeader location={useLocation()} />
         <div className="card px-3 py-5 flex-grow data-card telemetry">
            <h2 className="page-heading fw-600 mb-lg">Users List </h2>
            <IotTable columns={tableColumns} data={getTableData()} />
         </div>
         <Spinner show={userListRequestLoading} msg="Getting records..." />
      </>
   );
}

const mapStateToProps = createStructuredSelector({
   userToken: userSelectors.selectUserToken
});

export default connect(mapStateToProps)(UsersList);
