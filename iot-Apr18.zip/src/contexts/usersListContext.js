import { useState, createContext, useContext } from 'react';

const usersListContext = createContext();

const usersListContextProvider = props => {
   return <usersListContext>{props.children}</usersListContext>;
};

export const useUsersListContext = () => useContext(usersListContext);
