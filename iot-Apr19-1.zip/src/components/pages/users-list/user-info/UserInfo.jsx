import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';

import * as userSelectors from '../../../../redux/user/user-selectors';
import * as portfolioSelectors from '../../../../redux/portfolio/portfolio-selectors';

import API from '../../../../utils/apiUtils';

import Backdrop from '../../../UI/backdrop/Backdrop';
import InputField from '../../../UI/InputField';

import useInput from '../../../../hooks/useInput';
import useMultiSelect from '../../../../hooks/useMultiSelect';
import useFetch from '../../../../hooks/useFetch';

import InputGroup from 'react-bootstrap/InputGroup';
import MultipleSelect from '../../../UI/multi-select/MultipleSelect';
import Spinner from '../../../UI/spinner/Spinner';
import BoostrapSpinner from 'react-bootstrap/Spinner';

function UserInfo({ user, show, close }) {
   const [fieldsEditable, setFieldsEditable] = useState(false);
   const userFullName = user.firstName + ' ' + user.lastName;

   const handleSave = () => {};

   const handleSubmit = ev => {
      ev.preventDefault();
      if (!fieldsEditable) return setFieldsEditable(true);
      handleSave();
   };

   const {
      inputValue: userName,
      handleChange: handleChangeUserName,
      runValidators: runUserNameValidators,
      validationErrors: userNameValidationErrors,
      setValidationErrors: setUserNameValidationErrors
   } = useInput({ init: userFullName, validators: [{ isRequired: [] }] });

   const {
      inputValue: email,
      handleChange: handleChangeEmail,
      runValidators: runEmailValidators,
      validationErrors: emailValidationErrors,
      setValidationErrors: setEmailValidationErrors
   } = useInput({ init: user.emailID, validators: [{ isRequired: [] }] });

   const {
      inputValue: phone,
      handleChange: handleChangePhone,
      runValidators: runPhoneValidators,
      validationErrors: phoneValidationErrors,
      setValidationErrors: setPhoneValidationErrors
   } = useInput({ init: user.contactNumber, validators: [{ isRequired: [] }] });

   const containerClassName = `add-group thin-scrollbar ${
      show ? 'show' : 'fade'
   }`;
   return (
      <>
         <div className={containerClassName}>
            <h2 className="page-heading fw-600 mb-lg my-sm-5">User Info</h2>
            <form className="w-md-75" onSubmit={handleSubmit}>
               <InputGroup className="mb-4 row">
                  <label
                     htmlFor={userFullName}
                     className="col-sm-4 col-form-label"
                  >
                     User Name
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     {!fieldsEditable ? (
                        <span>{userFullName}</span>
                     ) : (
                        <InputField
                           type="text"
                           id={userFullName}
                           className=""
                           value={userName}
                           onChange={handleChangeUserName}
                           validationErrors={userNameValidationErrors}
                        />
                     )}
                  </div>
                  <hr className="my-3"></hr>
               </InputGroup>

               <InputGroup className="mb-4 row">
                  <label
                     htmlFor={user.propertyName}
                     className="col-sm-4 col-form-label"
                  >
                     Property Name
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <span>{user.propertyName}</span>
                     {/* <InputField
                     type="text"
                     id="groupName"
                     className=""
                     value={userName}
                     onChange={handleChangeUserName}
                     validationErrors={userNameValidationErrors}
                  /> */}
                  </div>
               </InputGroup>

               <InputGroup className="mb-4 row">
                  <label
                     htmlFor={user.emailID}
                     className="col-sm-4 col-form-label"
                  >
                     Primary Email
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     {!fieldsEditable ? (
                        <span>{user.emailID}</span>
                     ) : (
                        <InputField
                           type="text"
                           id={user.emailID}
                           className=""
                           value={email}
                           onChange={handleChangeEmail}
                           validationErrors={emailValidationErrors}
                        />
                     )}
                  </div>
                  {/* <hr className="my-3"></hr> */}
               </InputGroup>

               <InputGroup className="mb-4 row">
                  <label
                     htmlFor={user.contactNumber}
                     className="col-sm-4 col-form-label"
                  >
                     Phone
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     {!fieldsEditable ? (
                        <span>{user.contactNumber}</span>
                     ) : (
                        <InputField
                           type="number"
                           id={user.contactNumber}
                           className=""
                           value={phone}
                           onChange={handleChangePhone}
                           validationErrors={phoneValidationErrors}
                        />
                     )}
                  </div>
                  {/* <hr className="my-3"></hr> */}
               </InputGroup>

               <hr className="my-3"></hr>

               <InputGroup className="mb-4 row">
                  <label
                     htmlFor="groupName"
                     className="col-sm-4 col-form-label"
                  >
                     Define Role
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     {/* <InputField
                     type="text"
                     id="groupName"
                     className=""
                     value={userName}
                     onChange={handleChangeUserName}
                     validationErrors={userNameValidationErrors}
                  /> */}
                  </div>
                  {/* <hr className="my-3"></hr> */}
               </InputGroup>

               <InputGroup className="mb-4 row">
                  <label
                     htmlFor="groupName"
                     className="col-sm-4 col-form-label"
                  >
                     Add Group
                  </label>
                  <div className="col-sm-8" style={{ position: 'relative' }}>
                     <span>{user.roleName}</span>
                     {/* <InputField
                     type="text"
                     id="groupName"
                     className=""
                     value={userName}
                     onChange={handleChangeUserName}
                     validationErrors={userNameValidationErrors}
                  /> */}
                  </div>
                  {/* <hr className="my-3"></hr> */}
               </InputGroup>
               <div className="actions">
                  <button
                     type="submit"
                     className="rounded btn btn-primary"
                     data-dismiss="modal"
                     aria-label="Close"
                     // disabled={addGroupRequestLoading}
                  >
                     {null ? (
                        <div className="d-flex align-items-center">
                           Saving...{' '}
                           <BoostrapSpinner
                              animation="border"
                              size="sm"
                           ></BoostrapSpinner>
                        </div>
                     ) : !fieldsEditable ? (
                        'Edit'
                     ) : (
                        'Save'
                     )}
                  </button>
                  <button
                     type="button"
                     className="rounded btn btn-outline-dark"
                     data-dismiss="modal"
                     aria-label="Close"
                     onClick={close}
                  >
                     Cancel
                  </button>
               </div>
            </form>
         </div>

         <Backdrop show={show} />
      </>
   );
}

export default UserInfo;
