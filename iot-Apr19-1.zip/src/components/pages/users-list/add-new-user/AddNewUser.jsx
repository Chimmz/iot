import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';

import * as userSelectors from '../../../../redux/user/user-selectors';
import * as portfolioSelectors from '../../../../redux/portfolio/portfolio-selectors';

import useInput from '../../../../hooks/useInput';
import API from '../../../../utils/apiUtils';

import Backdrop from '../../../UI/backdrop/Backdrop';
import InputField from '../../../UI/InputField';

import useList from '../../../../hooks/useList';
import useMultiSelect from '../../../../hooks/useMultiSelect';
import useFetch from '../../../../hooks/useFetch';

import { configurationContext } from '../../../../contexts/configurationContext';

// import {
//    getIncidentTypeOptions,
//    getNotificationOptions,
//    getAvailabilityOptions,
//    getSelectionValues
// } from './utils';

import InputGroup from 'react-bootstrap/InputGroup';
import MultipleSelect from '../../../UI/multi-select/MultipleSelect';
import Spinner from '../../../UI/spinner/Spinner';
import BoostrapSpinner from 'react-bootstrap/Spinner';

function AddNewUser() {
   const {
      inputValue: userName,
      handleChange: handleChangeUserName,
      runValidators: runUserNameValidators,
      validationErrors: userNameValidationErrors,
      setValidationErrors: setUserNameValidationErrors
   } = useInput({ init: '', validators: [{ isRequired: [] }] });

   const handleSave = ev => {};

   return (
      <div className="add-group thin-scrollbar">
         <h2 className="page-heading fw-600 mb-lg my-sm-5">Add New User</h2>
         <form onSubmit={handleSave} className="w-md-75">
            <InputGroup className="mb-4 row">
               <label htmlFor="groupName" className="col-sm-4 col-form-label">
                  Username
               </label>
               <div className="col-sm-8" style={{ position: 'relative' }}>
                  <InputField
                     type="text"
                     id="groupName"
                     className=""
                     value={userName}
                     onChange={handleChangeUserName}
                     validationErrors={userNameValidationErrors}
                  />
               </div>
            </InputGroup>
         </form>
      </div>
   );
}

export default AddNewUser;
