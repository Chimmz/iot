import React, { useEffect, useContext } from 'react';
import { NavLink } from 'react-router-dom';

import { dashboardContext } from '../../../../contexts/dashboardContext';
import { v4 as uuidv4 } from 'uuid';

import Dropdown from 'react-bootstrap/Dropdown';
import { sidebarLinks } from './config';
import './DashboardSidebar.scss';

// TO ADD A NEW LINK TO THE SIDEBAR, ADD IT IN ./config.js

function DashboardSidebar() {
   const { toggleSidebarCollapsed } = useContext(dashboardContext);
   const getActiveClassName = navData => navData.isActive && 'active';

   const showMenuItems = ev => {
      console.log(ev.target.closest('label').previousElementSibling);
      const checkbox = ev.target.closest('label').previousElementSibling;
      checkbox.checked = !checkbox.checked;
   };

   const showDropdown = dropdown => {
      const id = uuidv4();
      const dropdownLink = dropdown.linkTo ? dropdown.linkTo : '#';

      return (
         <div className="drop-down">
            <input type="checkbox" name="" id={id} />
            <label for={id} className="d-block">
               <NavLink
                  to={dropdown.linkTo || id}
                  className={`sidebar-link ${
                     !dropdown.linkTo && 'disabled-link'
                  } `}
                  onClick={showMenuItems}
                  activeClassName={getActiveClassName}
               >
                  <img src={process.env.PUBLIC_URL + dropdown.imgSrc} alt="" />
                  <span>{dropdown.label}</span>
               </NavLink>
            </label>
            {/* Dropdown Menu Items */}
            <ul className="drop-down-items">
               {dropdown.subItems.map(item => (
                  <li className="drop-down-item">
                     <NavLink
                        to={item.linkTo}
                        activeClassName={getActiveClassName}
                     >
                        -- {item.label}
                     </NavLink>
                  </li>
               ))}
            </ul>
         </div>
      );
   };

   const showSingleLink = link => (
      <NavLink to={link.linkTo} className="sidebar-link">
         <img src={process.env.PUBLIC_URL + link.imgSrc} alt="" />
         <span>{link.label}</span>
      </NavLink>
   );

   return (
      <aside className="mainSideBar">
         <button
            className="btn btn-close d-md-none"
            onClick={toggleSidebarCollapsed}
         ></button>
         <p className="title fs14">main</p>

         <div className="side-links">
            {sidebarLinks.map(link =>
               link.hasMenu ? showDropdown(link) : showSingleLink(link)
            )}
         </div>
      </aside>
   );
}

export default DashboardSidebar;
