import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

// Redux
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import * as portfolioSelectors from '../../../redux/portfolio/portfolio-selectors';
import * as userSelectors from '../../../redux/user/user-selectors';
import * as incidentSelectors from '../../../redux/incident/incident-selectors';

import * as incidentUtils from '../../../redux/incident/incident-utils';

import Spinner from '../../UI/spinner/Spinner';
import IotTable from '../../iot-table/IotTable';

import {
   tableColumns,
   getTableData,
   dateFilterPeriods,
   sortByStartTime
} from './table-config.js';

import PageHeader from '../../page-header/PageHeader';
import './Telemetry.scss';

function Telemetry(props) {
   const { currentPortfolio, userToken } = props;
   const [incidents, setIncidents] = useState([]);

   const [currentTimePeriod, setCurrentTimePeriod] = useState('1-week');
   const [filteredDataLoading, setIsFilteredDataLoading] = useState(false);

   const loadIncidents = async () => {
      const makeRequest = () => {
         return incidentUtils.fetchIncidents(
            currentPortfolio,
            currentTimePeriod,
            userToken
         );
      };
      const res = incidentUtils.handleFilterLoadingAsync(
         makeRequest,
         setIsFilteredDataLoading
      );
      const incids = await res;
      console.log('INCIDS: ', incids);
      setIncidents(incids);
   };

   useEffect(() => {
      if (currentPortfolio) loadIncidents();
   }, [currentTimePeriod, currentPortfolio?.portfolioHeaderId]);

   const handleDateFilter = function (evKey) {
      const periodSelected = evKey;
      if (periodSelected === currentTimePeriod) return; // If active date filter was selected again
      setCurrentTimePeriod(evKey);
   };

   return (
      <>
         <Spinner show={filteredDataLoading} message="Getting records..." />
         <PageHeader location={useLocation()} />
         <div className="card px-3 py-5 flex-grow data-card telemetry">
            <h2 className="page-heading fw-600 mb-lg">Telemetry </h2>

            <IotTable
               columns={tableColumns}
               data={getTableData(sortByStartTime(incidents, 'descend'))}
               currentTimePeriod={currentTimePeriod}
               dateFilterPeriods={dateFilterPeriods}
               onDateFilter={handleDateFilter}
            />
         </div>
      </>
   );
}

const mapStateToProps = createStructuredSelector({
   currentPortfolio: portfolioSelectors.selectCurrentPortfolio,
   incidentsLoading: incidentSelectors.selectIncidentLoading,
   userToken: userSelectors.selectUserToken
});

export default connect(mapStateToProps)(Telemetry);
