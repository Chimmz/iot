import API from '../../utils/apiUtils';
import * as dateUtils from '../../utils/dateUtils';

export const fetchIncidents = function (portfolio, timePeriod, userToken) {
   const [fromDate, toDate] = dateUtils.getDateRangeBasedOnPeriod(timePeriod);

   console.log('LOGGING: ', fromDate, toDate);

   // Returns a promise
   return API.getIncidentsByPortfolio(
      userToken,
      portfolio.portfolioHeaderId,
      fromDate.toISOString(),
      toDate.toISOString()
   );
};

export const handleFilterLoadingAsync = (fn, setLoading) => {
   setLoading(true);

   return fn()
      .then(res => {
         setLoading(false);
         return res;
      })
      .catch(err => {
         setLoading(false);
         throw err;
      });
};
