export const userStatus = {
   USER_VALID: 'USER_VALID',
   DEFAULT_USER: 'DEFAULT_USER'
};
